// Exercise 1: Basic Readonly Property
// Define a class named Car with the following properties:

// readonly make: string
// readonly model: string
// readonly year: number
// Initialize these properties using the constructor parameters.
// Create an instance of the Car class and attempt to modify one of its properties to see the compile-time error.

// Exercise 2: Readonly Property in a Method
// Define a class named Rectangle with the following properties:

// readonly width: number
// readonly height: number
// Add a method getArea() that calculates and returns the area of the rectangle.
// Test the method by creating an instance of the Rectangle class and calling getArea().

// Exercise 3: Combining Readonly with Other Access Modifiers
// Define a class named Book with the following properties:

// readonly title: string
// private author: string
// public yearPublished: number
// Initialize these properties using the constructor parameters.
// Add a method getBookInfo() that returns a string containing the book's title, author, and year published.
// Test the method by creating an instance of the Book class and calling getBookInfo().

// Exercise 4: Readonly Property in Derived Class
// Define a class named Employee with the following properties:

// readonly employeeId: number
// readonly name: string
// Create a subclass named Manager that extends Employee and adds the following property:

// readonly department: string
// Initialize all properties using the constructor parameters.
// Create an instance of the Manager class and display the values of its properties.

// Exercise 5: Consolidated Declaration and Initialization
// Define a class named Person with the following properties:

// readonly firstName: string
// readonly lastName: string
// readonly age: number
// Use the constructor to initialize these properties in a consolidated manner.
// Create an instance of the Person class and try to modify one of its properties to see the compile-time error.
