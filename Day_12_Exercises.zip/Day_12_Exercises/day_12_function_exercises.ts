// Exercise 1: Calculate Rectangle Area
// Write a function named calculateRectangleArea that takes two parameters: width and height of type number.
// The function should return the area of the rectangle, which is also a number.

// Exercise 2: Concatenate Strings
// Create a function named concatenateStrings that takes two parameters: str1 and str2 of type string.
// The function should return the concatenated result of the two strings.

// Exercise 3: Check Even or Odd
// Write a function named isEven that takes a parameter num of type number and returns a boolean.
// The function should return true if the number is even and false if the number is odd.

// Exercise 4: Find Maximum Number
// Create a function named findMax that takes an array of numbers as a parameter and returns the maximum number in the array.
// Ensure to specify the types for the parameter and return value.

// Exercise 5: Greet User
// Write a function named greetUser that takes a parameter name of type string and returns a greeting message of type string.
// The message should be in the format: "Hello, [name]!".

// Instructions:
// Define each function with appropriate type annotations for parameters and return types.
// Test each function with different inputs to ensure they work as expected.
// Ensure that each function's implementation adheres to the type constraints specified.
