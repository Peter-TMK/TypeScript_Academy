// Exercise 1: Declaring Boolean Variables
// Declare three boolean variables: isPending, isComplete, and hasErrors.
// Assign values to them and log the results to the console.

// Exercise 2: Using Boolean Operators
// Create boolean expressions using the logical AND (&&), OR (||), and NOT (!) operators
// with the boolean variables from Exercise 1. Log the results to the console.

// Exercise 3: Type Annotations
// Declare boolean variables with explicit type annotations.
// Initialize them with values and log the results to the console.

// Exercise 4: Boolean Function Parameters
// Create a function named toggleStatus that takes a boolean parameter status and returns the
// negated value of status. Test the function by passing in both true and false and log the results to the console.

// Exercise 5: Conditional Statements
// Write a function named checkStatus that takes two boolean parameters: isComplete and hasErrors.
// The function should return a string message based on the following conditions:

// If isComplete is true and hasErrors is false, return "Task completed successfully."
// If isComplete is false, return "Task is still pending."
// If hasErrors is true, return "Task encountered errors."
// Test the function with different combinations of isComplete and hasErrors
// and log the results to the console.

// These exercises will help you get hands-on experience with TypeScript's boolean data type,
// including declaring variables, using boolean operators, working with type annotations,
// and writing functions that take and return boolean values.
