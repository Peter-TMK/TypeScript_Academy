// Exercise 1: Declare and Initialize an Array
// Declare an array named hobbies that holds string values and initialize it with at least three hobbies.
// Log the hobbies array to the console.

// Exercise 2: Add Elements to an Array
// Using the hobbies array from Exercise 1, add two more hobbies
// using both index notation and the push() method. Log the updated hobbies array to the console.

// Exercise 3: Type Inference and Type Checking
// Declare an array named languages and initialize it with
// string values representing programming languages.
// Try to add a number to the languages array and observe the TypeScript error.
// Then, extract the first element from the languages array and log its type using typeof.

// Exercise 4: Array Methods
// Using the languages array from Exercise 3, perform the following operations:

// Use the forEach() method to log each language to the console.
// Use the map() method to create a new array with all languages in uppercase
// and log the new array to the console.
// Use the filter() method to create a new array with languages that contain
// the letter 'a' and log the new array to the console.

// Exercise 5: Mixed Type Array
// Declare an array named mixedValues that holds both string and number values.
// Initialize it with at least two strings and two numbers.
// Log the mixedValues array to the console.
// Then, use the reduce() method to concatenate all string values and log the result to the console.

// These exercises will help you practice declaring and initializing arrays,
// adding elements, type inference, and using various array methods in TypeScript.
