// Exercise 1: Basic Union Type
// Declare a variable mixedValue that can hold either a string or a number.
// Assign different values (both string and number) to mixedValue and log them to the console.

// Exercise 2: Function with Union Type Parameters
// Write a function named describeValue that takes one parameter of type number | string.
// The function should return a message indicating whether the value is a number or a string.
// Test the function with different values and log the results to the console.

// Exercise 3: Array with Union Type Elements
// Declare an array named mixedArray that can hold elements of type number | string.
// Initialize it with at least two numbers and two strings.
// Use a loop to iterate over the array and log each element's type (number or string) to the console.

// Exercise 4: Advanced Function with Union Type Parameters
// Write a function named processValues that takes two parameters of type number | string.
// The function should:

// If both parameters are numbers, return their product.
// If both parameters are strings, return their concatenation.
// If one parameter is a number and the other is a string, throw an error.
// Test the function with different combinations of values and log the results to the console.

// Exercise 5: Handling Union Types in Arrays
// Declare a function named filterNumbers that takes an array of number | string as a parameter and
// returns a new array containing only the numbers from the input array.
// Test the function with an array containing both numbers and strings and log the result to the console.
